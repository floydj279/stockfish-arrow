// GPL-3.0-or-later. Routes page requests to the local Stockfish worker.
const OFFSCREEN_PATH = 'src/offscreen.html';
let creating;
const latest = new Map();

export function validFen(fen) {
  if (typeof fen !== 'string' || fen.length > 120 || /[\r\n]/.test(fen)) return false;
  const fields = fen.trim().split(/\s+/);
  if (fields.length !== 6) return false;
  const [placement, turn, rights, ep, halfmove, fullmove] = fields;
  const ranks = placement.split('/');
  if (ranks.length !== 8 || !/^[wb]$/.test(turn) || !/^(?:-|K?Q?k?q?)$/.test(rights) || !rights) return false;
  if (!/^(?:-|[a-h][36])$/.test(ep) || !/^\d+$/.test(halfmove) || !/^[1-9]\d*$/.test(fullmove)) return false;
  if ((placement.match(/K/g) || []).length !== 1 || (placement.match(/k/g) || []).length !== 1) return false;
  return ranks.every(rank => /^[prnbqkPRNBQK1-8]+$/.test(rank) && [...rank].reduce((sum, c) => sum + (/\d/.test(c) ? Number(c) : 1), 0) === 8);
}

export function allowedSender(sender, extensionId) {
  if (sender.id !== extensionId || (sender.frameId ?? 0) !== 0) return false;
  try {
    const url = new URL(sender.url || sender.tab?.url || '');
    return (url.protocol === 'https:' && (url.hostname === 'chess.com' || url.hostname.endsWith('.chess.com')))
      || (url.protocol === 'chrome-extension:' && url.hostname === extensionId);
  } catch { return false; }
}

async function ensureOffscreen() {
  if (creating) return creating;
  creating = (async () => {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [chrome.runtime.getURL(OFFSCREEN_PATH)],
    });
    if (!contexts.length) {
      await chrome.offscreen.createDocument({
        url: OFFSCREEN_PATH,
        reasons: ['WORKERS'],
        justification: 'Run the bundled Stockfish WebAssembly chess engine in a local worker.',
      });
    }
  })();
  try { await creating; } finally { creating = undefined; }
}

function failed(message, error) {
  return {ok: false, requestId: message.requestId, fen: message.fen, error};
}

if (globalThis.chrome?.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.target === 'stockfish-offscreen' || !['ANALYZE', 'CANCEL'].includes(message.type)) return;
    if (!allowedSender(sender, chrome.runtime.id)) {
      sendResponse(failed(message, 'This page is not allowed to request analysis.'));
      return;
    }
    if (message.type === 'ANALYZE' && (!validFen(message.fen) || !['number', 'string'].includes(typeof message.requestId))) {
      sendResponse(failed(message, 'The board position is incomplete or invalid.'));
      return;
    }
    const clientId = Number.isInteger(sender.tab?.id) ? `tab:${sender.tab.id}` : `page:${sender.documentId || sender.url}`;
    const cancellationTicket = message.type === 'CANCEL' ? latest.get(clientId) : undefined;
    const ticket = {requestId: message.requestId};
    if (message.type === 'ANALYZE') latest.set(clientId, ticket);
    else if (message.requestId === undefined || latest.get(clientId)?.requestId === message.requestId) latest.delete(clientId);
    // The caller cannot choose another tab's client identifier.
    const payload = {
      target: 'stockfish-offscreen',
      type: message.type,
      clientId,
      requestId: message.type === 'CANCEL' ? (message.requestId ?? cancellationTicket?.requestId) : message.requestId,
      fen: message.fen,
      movetime: Math.max(100, Math.min(10000, Number(message.movetime) || 1500)),
      depth: Math.max(1, Math.min(40, Math.floor(Number(message.depth) || 24))),
    };
    (async () => {
      if (message.type === 'CANCEL') {
        const contexts = await chrome.runtime.getContexts({contextTypes: ['OFFSCREEN_DOCUMENT']});
        if (!contexts.length) return {ok: true, requestId: message.requestId, cancelled: false};
        // getContexts is asynchronous: a later ANALYZE may already have started.
        // Never allow this older cancellation to stop that newer position.
        const currentTicket = latest.get(clientId);
        if (currentTicket && currentTicket !== cancellationTicket) {
          return {ok: true, requestId: message.requestId, cancelled: false};
        }
      } else {
        await ensureOffscreen();
        if (latest.get(clientId) !== ticket) return {...failed(message, 'Analysis cancelled.'), cancelled: true};
      }
      const result = await chrome.runtime.sendMessage(payload);
      if (message.type === 'ANALYZE' && latest.get(clientId) !== ticket) return {...failed(message, 'Analysis cancelled.'), cancelled: true};
      return result;
    })().then(result => sendResponse(result || failed(message, 'The engine did not respond.')))
      .catch(error => sendResponse(failed(message, `Unable to run Stockfish: ${error.message}`)));
    return true;
  });
  chrome.tabs.onRemoved.addListener(tabId => {
    latest.delete(`tab:${tabId}`);
    chrome.runtime.sendMessage({target: 'stockfish-offscreen', type: 'CANCEL', clientId: `tab:${tabId}`}).catch(() => {});
  });
  chrome.action.onClicked.addListener(tab => {
    if (tab.id) chrome.tabs.sendMessage(tab.id, {type: 'TOGGLE'}).catch(() => {
      chrome.tabs.create({url: chrome.runtime.getURL('demo.html')});
    });
  });
  chrome.commands.onCommand.addListener(async command => {
    if (command !== 'toggle-arrow') return;
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    if (tab?.id) chrome.tabs.sendMessage(tab.id, {type:'TOGGLE'}).catch(() => {});
  });
}
