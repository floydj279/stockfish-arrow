/* Read only rendered board data. No Chess.com private application state. */
const PIECE = /^[wb][pnbrqk]$/;
const FILES = 'abcdefgh';
const BOARD_SELECTOR = 'wc-chess-board, chess-board';

export function parseSquareClass(value) {
  const match = /(?:^|\s)square-([1-8])([1-8])(?:\s|$)/.exec(String(value));
  return match ? FILES[Number(match[1]) - 1] + match[2] : null;
}

export function squareCenter(square, flipped = false) {
  if (!/^[a-h][1-8]$/.test(square)) throw new Error('Invalid algebraic square.');
  const file = FILES.indexOf(square[0]);
  const rank = Number(square[1]) - 1;
  return {
    x: ((flipped ? 7 - file : file) + 0.5) / 8,
    y: ((flipped ? rank : 7 - rank) + 0.5) / 8,
  };
}

export function piecesToPlacement(pieces) {
  const squares = new Map();
  for (const {piece, square} of pieces) {
    if (!PIECE.test(piece) || !/^[a-h][1-8]$/.test(square)) {
      throw new Error('An unrecognized piece or square was found.');
    }
    if (squares.has(square)) throw new Error('Pieces are moving or overlap; wait for the board to settle.');
    squares.set(square, piece[0] === 'w' ? piece[1].toUpperCase() : piece[1]);
  }
  const rows = [];
  for (let rank = 8; rank >= 1; rank--) {
    let row = '', empty = 0;
    for (const file of FILES) {
      const piece = squares.get(file + rank);
      if (!piece) { empty++; continue; }
      if (empty) row += empty;
      empty = 0;
      row += piece;
    }
    if (empty) row += empty;
    rows.push(row);
  }
  return rows.join('/');
}

/** Syntactic FEN validation; the chess rules layer validates legal positions. */
export function parseFen(value) {
  if (typeof value !== 'string') return null;
  const fields = value.trim().split(/\s+/);
  if (fields.length !== 6) return null;
  const [placement, turn, castling, ep, halfmove, fullmove] = fields;
  const ranks = placement.split('/');
  if (ranks.length !== 8 || ranks.some(rank => {
    if (!/^[prnbqkPRNBQK1-8]+$/.test(rank) || /[1-8]{2}/.test(rank)) return true;
    return [...rank].reduce((n, char) => n + (/\d/.test(char) ? Number(char) : 1), 0) !== 8;
  })) return null;
  if (!/^[wb]$/.test(turn) || !/^(?:-|K?Q?k?q?)$/.test(castling) || !castling) return null;
  if (!/^(?:-|[a-h][36])$/.test(ep)) return null;
  if ((turn === 'w' && /3$/.test(ep)) || (turn === 'b' && /6$/.test(ep))) return null;
  if (!/^\d+$/.test(halfmove) || !/^[1-9]\d*$/.test(fullmove)) return null;
  if (!Number.isSafeInteger(Number(halfmove)) || !Number.isSafeInteger(Number(fullmove))) return null;
  return {fen: fields.join(' '), placement, turn, castling, ep};
}

function classNames(element) {
  // SVG className is an object; getAttribute handles both SVG and HTML.
  return element.getAttribute?.('class') || '';
}

function isVisible(element, doc) {
  if (!element || element.hidden) return false;
  const rect = element.getBoundingClientRect?.();
  if (!rect || rect.width <= 0 || rect.height <= 0) return false;
  const style = doc.defaultView?.getComputedStyle?.(element);
  return !style || (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0');
}

function readTurnAttribute(board) {
  for (const name of ['turn', 'data-turn', 'active-color', 'data-active-color']) {
    const value = board.getAttribute(name)?.toLowerCase();
    if (value === 'w' || value === 'white') return 'w';
    if (value === 'b' || value === 'black') return 'b';
  }
  return null;
}

function readFlipped(board) {
  if (/(?:^|\s)flipped(?:\s|$)/.test(classNames(board))) return true;
  const orientation = board.getAttribute('orientation') || board.getAttribute('data-orientation');
  if (orientation) return orientation.toLowerCase() === 'black';
  return board.getAttribute('data-flipped') === 'true';
}

function readMatchingFen(doc, board, placement) {
  const candidates = [];
  for (const name of ['fen', 'data-fen', 'position', 'data-position']) {
    candidates.push({value: board.getAttribute(name), source: 'board-fen'});
  }
  // Only explicit FEN-labelled form controls; do not search arbitrary page text,
  // hidden app state, another game, or the clipboard.
  const fields = doc.querySelectorAll('input[name="fen" i], textarea[name="fen" i], input[id="fen" i], textarea[id="fen" i], input[aria-label*="FEN" i], textarea[aria-label*="FEN" i]');
  for (const element of fields) {
    if (isVisible(element, doc)) candidates.push({value: element.value, source: 'visible-fen'});
  }
  for (const candidate of candidates) {
    const parsed = parseFen(candidate.value);
    if (parsed && parsed.placement === placement) return {...parsed, source: candidate.source};
  }
  return null;
}

/**
 * Read the largest visible Chess.com board. Unknown history remains unknown:
 * piece placement alone cannot reveal turn, castling rights or en passant.
 * Returns null when no supported visible board is present.
 */
export function readBoard(doc = document) {
  const boards = [...doc.querySelectorAll(BOARD_SELECTOR)]
    .filter(board => isVisible(board, doc))
    .sort((a, b) => {
      const ar = a.getBoundingClientRect(), br = b.getBoundingClientRect();
      return br.width * br.height - ar.width * ar.height;
    });
  const boardElement = boards[0];
  if (!boardElement) return null;
  const base = {boardElement, flipped: readFlipped(boardElement), fen: null, turn: null, source: 'pieces', warning: null};
  const pieces = [];
  const roots = [boardElement, boardElement.shadowRoot].filter(Boolean);
  for (const root of roots) {
    for (const element of root.querySelectorAll('.piece')) {
      if (!isVisible(element, doc)) continue;
      const classes = classNames(element);
      const square = parseSquareClass(classes);
      const piece = classes.split(/\s+/).find(name => PIECE.test(name));
      // Ghosts / drag helpers without a square are not board pieces.
      if (!square || !piece) continue;
      pieces.push({piece, square});
    }
  }
  if (!pieces.length) return {...base, placement: null, error: 'No readable pieces found on this board.'};
  let placement;
  try { placement = piecesToPlacement(pieces); }
  catch (error) { return {...base, placement: null, error: error.message}; }
  const explicit = readMatchingFen(doc, boardElement, placement);
  if (explicit) return {...base, placement, fen: explicit.fen, turn: explicit.turn, source: explicit.source};
  return {
    ...base,
    placement,
    turn: readTurnAttribute(boardElement),
    warning: 'The visible pieces do not reveal castling rights or en passant. Use a full FEN for an exact position.',
  };
}
