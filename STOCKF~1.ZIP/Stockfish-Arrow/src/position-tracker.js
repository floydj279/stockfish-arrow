import {Chess} from '../vendor/chess.mjs';

const START_PLACEMENT = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR';
const HISTORY_LIMIT = 256;
const placementOf = fen => fen.split(' ')[0];
const turnOf = fen => fen.split(' ')[1];

function matches(fen, snapshot) {
  return placementOf(fen) === snapshot.placement && (!snapshot.turn || turnOf(fen) === snapshot.turn);
}

function unknown(warning, error) {
  return {fen: null, source: 'unknown', ...(warning ? {warning} : {}), ...(error ? {error} : {})};
}

/** Keeps legal game state only when it can be derived without inventing history. */
export class PositionTracker {
  constructor() { this.reset(); }

  reset() {
    this.history = [];
    this.cursor = -1;
  }

  /** A full FEN is an explicit synchronization point. Invalid seeds keep old state. */
  seed(fen) {
    if (typeof fen !== 'string' || fen.trim().split(/\s+/).length !== 6) {
      return unknown(null, 'Invalid FEN: provide all six FEN fields.');
    }
    let game;
    try { game = new Chess(fen); }
    catch (error) { return unknown(null, `Invalid FEN: ${error.message}`); }
    this.reset();
    this.history.push(game.fen());
    this.cursor = 0;
    return {fen: game.fen(), source: 'manual'};
  }

  get currentFen() { return this.history[this.cursor] || null; }

  remember(fen, source) {
    if (this.currentFen === fen) return {fen, source};
    // A new branch replaces forward navigation but retains its known ancestors.
    this.history = this.history.slice(0, this.cursor + 1);
    this.history.push(fen);
    if (this.history.length > HISTORY_LIMIT) this.history.shift();
    this.cursor = this.history.length - 1;
    return {fen, source};
  }

  restore(index) {
    this.cursor = index;
    return {fen: this.currentFen, source: 'history'};
  }

  update(snapshot) {
    if (!snapshot?.placement) return unknown(null, snapshot?.error || 'No readable board position.');

    // An explicit matching FEN overrides every inferred/tracked position.
    if (snapshot.fen) {
      let fen;
      try { fen = new Chess(snapshot.fen).fen(); }
      catch (error) { return unknown(null, `Invalid board FEN: ${error.message}`); }
      if (!matches(fen, snapshot)) return unknown(null, 'The FEN does not match the visible board or side to move.');
      return this.remember(fen, snapshot.source || 'board-fen');
    }

    if (this.currentFen) {
      if (matches(this.currentFen, snapshot)) return {fen: this.currentFen, source: 'tracked'};

      // Every state change is validated through the chess rules implementation,
      // including castling, en passant, and every promotion choice.
      const game = new Chess(this.currentFen);
      const next = new Set();
      for (const move of game.moves({verbose: true})) {
        game.move({from: move.from, to: move.to, ...(move.promotion ? {promotion: move.promotion} : {})});
        const fen = game.fen();
        if (matches(fen, snapshot)) next.add(fen);
        game.undo();
      }
      if (next.size === 1) {
        const fen = [...next][0];
        if (this.history[this.cursor + 1] === fen) return this.restore(this.cursor + 1);
        return this.remember(fen, 'tracked');
      }
      if (next.size > 1) return unknown('More than one legal state matches these pieces. Paste a full FEN to synchronize.');

      // Adjacent navigation preserves counters and castling/en-passant state.
      const adjacent = [this.cursor - 1, this.cursor + 1]
        .filter(index => index >= 0 && index < this.history.length && matches(this.history[index], snapshot));
      if (adjacent.length === 1) return this.restore(adjacent[0]);

      const previous = this.history.map((fen, index) => ({fen, index}))
        .filter(entry => matches(entry.fen, snapshot));
      const distinct = new Set(previous.map(entry => entry.fen));
      if (distinct.size === 1) return this.restore(previous[previous.length - 1].index);
      if (distinct.size > 1 || adjacent.length > 1) {
        return unknown('This board position occurs more than once in the observed history. Paste its full FEN to choose the correct state.');
      }
    }

    if (snapshot.placement === START_PLACEMENT && (!snapshot.turn || snapshot.turn === 'w')) {
      return this.remember(new Chess().fen(), 'start-position');
    }
    return unknown('Move history is unknown. Open a new board from the starting position, or paste the current full FEN.');
  }
}
