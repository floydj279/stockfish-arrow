import {Chess} from '../vendor/chess.mjs';
import {readBoard, squareCenter} from './board-reader.js';
import {PositionTracker} from './position-tracker.js';

if (!document.getElementById('stockfish-arrow-root')) start();
function start() {
  const tracker = new PositionTracker();
  let enabled = false, board = null, currentFen = null, lastKey = '', pending = 0;
  let stablePlacement = '', stableSince = 0, lastUrl = location.href, lastElement = null, lastMove = null;
  let movetime = 1500, dead = false, collapsed = false;
  const host = document.createElement('div');
  host.id = 'stockfish-arrow-root';
  host.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483646;';
  const shadow = host.attachShadow({mode:'open'});
  shadow.innerHTML = `
    <style>
      :host{font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:#f3f5ee;font-size:13px}
      *{box-sizing:border-box}button,select,input,textarea{font:inherit}
      #panel{font:13px/1.4 system-ui,-apple-system,Segoe UI,sans-serif;color:#f3f5ee;position:fixed;right:20px;bottom:20px;width:292px;background:#1b211e;border:1px solid #3a463d;border-radius:17px;box-shadow:0 12px 45px #0005;pointer-events:auto;overflow:hidden;max-height:calc(100vh - 24px);overflow-y:auto}
      header{display:flex;align-items:center;gap:9px;padding:14px 16px;background:#232c26;cursor:move;touch-action:none}
      .mark{font-size:25px;color:#b1ef76}h1{font-size:15px;margin:0;letter-spacing:-.3px}small{display:block;font-size:10px;color:#a6b3aa;margin-top:2px;letter-spacing:.6px;text-transform:uppercase}
      #min{margin-left:auto;border:0;background:none;color:#becac0;font-size:20px;cursor:pointer;padding:0 5px}
      #body{padding:15px}#status{line-height:1.5;color:#bdc9c0;min-height:40px;margin:0 0 12px}
      #move{font-size:24px;letter-spacing:-.6px;font-weight:700;color:#b1ef76;margin:0 0 4px;min-height:29px}
      #detail{color:#a4b2a8;font-size:11px;line-height:1.5;margin-bottom:12px}
      button{cursor:pointer;border-radius:9px;border:1px solid #506051;padding:8px 10px;background:#2b372d;color:#e6eee6}button:hover{filter:brightness(1.12)}
      #toggle{background:#ade679;color:#18200f;border:0;font-weight:700;width:100%;padding:10px}#toggle.on{background:#303d33;color:#e5ede6}
      .row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:12px 0}select,input,textarea{background:#111713;color:#eff5ed;border:1px solid #455348;border-radius:6px;padding:6px;min-width:0}select{max-width:160px}textarea{width:100%;min-height:67px;resize:vertical;font-size:11px;line-height:1.4}
      details{border-top:1px solid #354138;padding-top:11px;margin-top:12px}summary{cursor:pointer;color:#aabbac;font-size:11px}.note{font-size:10px;color:#95a297;line-height:1.5;margin:9px 0 0}
      .rights{display:flex;gap:10px;flex-wrap:wrap;margin:9px 0}.rights label{display:flex;gap:3px;align-items:center;font-size:11px}.rights input{margin:0}
      #arrow{position:fixed;overflow:visible;pointer-events:none;display:none}#panel.collapsed #body{display:none}#panel.collapsed{width:238px}
      @media(max-width:600px){#panel{right:8px;bottom:8px;width:260px}}
    </style>
    <svg id="arrow" viewBox="0 0 800 800" aria-label="Stockfish suggested move"><defs><marker id="head" markerWidth="5" markerHeight="5" refX="3.4" refY="2.5" orient="auto"><path d="M0 0 L4 2.5 L0 5 Z" fill="#b4ef63"/></marker></defs><circle id="origin" r="15" fill="#b4ef63" opacity=".85"/><line id="line" stroke="#b4ef63" stroke-width="15" stroke-linecap="round" opacity=".88" marker-end="url(#head)"/></svg>
    <section id="panel" aria-label="Stockfish Arrow controls">
      <header><span class="mark">♞</span><div><h1>Stockfish Arrow</h1><small>17.1 Lite · local engine</small></div><button id="min" title="Collapse controls" aria-label="Collapse controls">−</button></header>
      <div id="body"><div id="move">Ready when you are</div><div id="detail">Best move at the selected search time.</div><p id="status" role="status">Open a Chess.com board, then enable the arrow.</p>
        <button id="toggle">Enable arrow</button>
        <div class="row"><label for="time">Think time</label><select id="time"><option value="500">Fast · 0.5 second</option><option value="1500" selected>Balanced · 1.5 seconds</option><option value="4000">Deep · 4 seconds</option><option value="10000">Maximum · 10 seconds</option></select></div>
        <details id="position"><summary>Position setup / joining midgame</summary>
          <p class="note">Start before the first move for automatic tracking, or paste the current FEN. If using board settings, confirm whose turn it is and the remaining rights.</p>
          <label class="note" for="fen">Full FEN</label><textarea id="fen" placeholder="Paste the current board's FEN"></textarea><button id="apply">Use FEN</button>
          <div class="row"><label for="turn">To move</label><select id="turn"><option value="w">White</option><option value="b">Black</option></select></div>
          <div class="note">Castling still allowed</div><div class="rights"><label><input type="checkbox" value="K">White O-O</label><label><input type="checkbox" value="Q">White O-O-O</label><label><input type="checkbox" value="k">Black O-O</label><label><input type="checkbox" value="q">Black O-O-O</label></div>
          <div class="row"><label for="ep">En passant square</label><input id="ep" maxlength="2" value="-" style="width:52px" aria-label="En passant target square"></div>
          <button id="settings">Use board + these settings</button><p class="note">Unchecked castling and “−” en passant mean unavailable. These settings matter. Full FEN also preserves the move counters.</p>
        </details><p class="note">For analysis and bot practice. Chess.com prohibits engine help against other players. Alt+Shift+S toggles the arrow.</p>
      </div>
    </section>`;
  document.documentElement.append(host);
  const $ = id => shadow.getElementById(id);
  const status = text => {$('status').textContent = text;};
  function cancel() {
    pending++; lastKey = ''; lastMove = null; $('arrow').style.display = 'none';
    if (!dead) chrome.runtime.sendMessage({type:'CANCEL'}).catch(() => {});
  }
  function setEnabled(value) {
    enabled = value; cancel();
    $('toggle').textContent = value ? 'Pause arrow' : 'Enable arrow'; $('toggle').classList.toggle('on', value);
    if (!value) { $('move').textContent = 'Paused'; $('detail').textContent = 'Click Enable arrow to continue.'; status('The engine is paused.'); }
    else { status('Reading the board…'); tick(); }
  }
  $('toggle').addEventListener('click', () => setEnabled(!enabled));
  $('min').addEventListener('click', () => {collapsed = !collapsed; $('panel').classList.toggle('collapsed',collapsed);$('min').textContent=collapsed?'+':'−';$('min').setAttribute('aria-label',collapsed?'Expand controls':'Collapse controls');});
  $('time').addEventListener('change', () => {movetime=Number($('time').value);chrome.storage.local.set({movetime});cancel();tick();});
  chrome.storage.local.get(['movetime']).then(data => {if ([500,1500,4000,10000].includes(data.movetime)){movetime=data.movetime;$('time').value=String(movetime);}}).catch(()=>{});
  chrome.runtime.onMessage.addListener((message,_sender,reply) => {if(message?.type==='TOGGLE'){setEnabled(!enabled);reply({enabled});}});
  function applyFen(fen) {
    const snap = readBoard(document);
    try {
      const chess = new Chess(fen.trim());
      if (!snap?.placement || chess.fen().split(' ')[0] !== snap.placement) throw new Error('The FEN must match the board currently on screen.');
      const result = tracker.seed(chess.fen());
      if (!result.fen) throw new Error(result.error || 'Invalid position.');
      stablePlacement=snap.placement;stableSince=0;lastElement=snap.boardElement;lastUrl=location.href;
      $('position').open=false;cancel();setEnabled(true);
    } catch(error) {status(error.message);}
  }
  $('apply').addEventListener('click', () => applyFen($('fen').value));
  $('settings').addEventListener('click', () => {
    const snap=readBoard(document);if(!snap?.placement){status('Wait until a complete board is visible.');return;}
    const rights=[...shadow.querySelectorAll('.rights input:checked')].map(e=>e.value).join('')||'-';
    applyFen(`${snap.placement} ${$('turn').value} ${rights} ${$('ep').value.trim()||'-'} 0 1`);
  });
  function draw() {
    if (!enabled || !lastMove || !board?.boardElement.isConnected) {$('arrow').style.display='none';return;}
    const rect=board.boardElement.getBoundingClientRect();
    if(rect.width<40||rect.height<40){$('arrow').style.display='none';return;}
    const a=squareCenter(lastMove.slice(0,2),board.flipped),b=squareCenter(lastMove.slice(2,4),board.flipped);
    const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),back=.022;
    for(const [name,val] of Object.entries({x1:a.x*800,y1:a.y*800,x2:(b.x-dx/len*back)*800,y2:(b.y-dy/len*back)*800})) $('line').setAttribute(name,val);
    $('origin').setAttribute('cx',a.x*800);$('origin').setAttribute('cy',a.y*800);
    Object.assign($('arrow').style,{display:'block',left:`${rect.left}px`,top:`${rect.top}px`,width:`${rect.width}px`,height:`${rect.height}px`});
  }
  function scoreText(score,fen) {
    if(!score)return '';const value=score.value*(fen.split(' ')[1]==='w'?1:-1);
    return score.type==='mate'?`Mate ${Math.abs(value)} · ${value>=0?'White':'Black'}`:`${value>=0?'+':''}${(value/100).toFixed(2)} · White's perspective`;
  }
  async function tick() {
    if(dead || document.hidden)return;
    const snap=readBoard(document);
    if(location.href!==lastUrl|| (snap && lastElement && snap.boardElement!==lastElement)) {tracker.reset();cancel();stablePlacement='';lastUrl=location.href;}
    board=snap;
    if(!snap?.placement) {if(lastMove||lastKey)cancel();if(enabled)status(snap?.error||'Waiting for a visible standard Chess.com board.');return;}
    lastElement=snap.boardElement;
    if(snap.placement!==stablePlacement) {stablePlacement=snap.placement;stableSince=Date.now();cancel();return;}
    if(Date.now()-stableSince<180)return;
    const position=tracker.update(snap);currentFen=position.fen;
    draw();
    if(!enabled)return;
    if(!currentFen) {$('move').textContent='Position setup needed';$('detail').textContent='Pieces found · move history unavailable';status('Open Position setup to paste FEN or confirm the board settings.');return;}
    const key=currentFen+'|'+movetime;
    if(key===lastKey)return;
    lastKey=key;lastMove=null;$('arrow').style.display='none';
    const requestId=++pending,fen=currentFen;
    $('move').textContent='Thinking…';$('detail').textContent=`${fen.split(' ')[1]==='w'?'White':'Black'} to move · ${movetime/1000}s search`;status('Stockfish is analyzing this position locally.');
    try {
      const result=await chrome.runtime.sendMessage({type:'ANALYZE',fen,requestId,movetime,depth:40});
      if(requestId!==pending||!enabled)return;
      const now=readBoard(document);
      if(!now||now.placement!==fen.split(' ')[0]) {cancel();return;}
      if(!result?.ok)throw new Error(result?.error||'The engine did not return a result.');
      const chess=new Chess(fen);
      if(!result.bestmove) {$('move').textContent=chess.isCheckmate()?'Checkmate':chess.isStalemate()?'Stalemate':'No legal move';$('detail').textContent='';status('There is no move to draw in this position.');return;}
      const uci=result.bestmove;
      const move=chess.move({from:uci.slice(0,2),to:uci.slice(2,4),promotion:uci[4]});
      if(!move)throw new Error('The engine result does not match the current board.');
      lastMove=uci;board=now;draw();$('move').textContent=`${move.san} · ${move.from} → ${move.to}`;
      $('detail').textContent=[scoreText(result.score,fen),`Depth ${result.depth||'—'}`].filter(Boolean).join(' · ');
      status(`${fen.split(' ')[1]==='w'?'White':'Black'} to move. Arrow updates after the next move.${uci[4]?' Promote to '+({q:'queen',r:'rook',b:'bishop',n:'knight'}[uci[4]])+'.':''}`);
    } catch(error) {
      if(requestId!==pending)return;
      $('move').textContent='Analysis unavailable';status(`${error.message} Pause and enable the arrow to retry.`);
      if(/context invalidated/i.test(error.message)){dead=true;status('Extension updated. Refresh this page to reconnect.');}
    }
  }
  let drag=null;
  shadow.querySelector('header').addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;const r=$('panel').getBoundingClientRect();drag={x:e.clientX-r.left,y:e.clientY-r.top};e.currentTarget.setPointerCapture(e.pointerId);});
  shadow.querySelector('header').addEventListener('pointermove',e=>{if(!drag)return;Object.assign($('panel').style,{left:Math.max(0,Math.min(innerWidth-$('panel').offsetWidth,e.clientX-drag.x))+'px',top:Math.max(0,Math.min(innerHeight-60,e.clientY-drag.y))+'px',right:'auto',bottom:'auto'});});
  shadow.querySelector('header').addEventListener('pointerup',()=>{drag=null;});
  window.addEventListener('scroll',draw,true);window.addEventListener('resize',draw);
  let scheduled=false;
  const observer=new MutationObserver(()=>{if(scheduled)return;scheduled=true;setTimeout(()=>{scheduled=false;tick();},100);});
  function observe(){observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['class','data-fen','fen','data-turn']});}
  observe();
  let timer=setInterval(tick,350);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)cancel();else tick();});
  window.addEventListener('pagehide',()=>{cancel();observer.disconnect();clearInterval(timer);timer=null;});
  window.addEventListener('pageshow',()=>{if(!timer){observe();timer=setInterval(tick,350);tick();}});
  tick();
}
