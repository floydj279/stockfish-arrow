import {Chess} from '../vendor/chess.mjs';
const board=document.getElementById('practice-board');
const presets={start:undefined,mate:'6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1',endgame:'8/5pk1/6p1/8/8/5P2/6PK/3R4 w - - 0 1'};
const glyph={k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'};
let game=new Chess(),flipped=false,selected=null;
function render(){
  board.replaceChildren();board.setAttribute('data-fen',game.fen());board.classList.toggle('flipped',flipped);
  for(let rank=1;rank<=8;rank++)for(let file=0;file<8;file++){
    const square='abcdefgh'[file]+rank,x=flipped?7-file:file,y=flipped?rank-1:8-rank;
    const tile=document.createElement('div');tile.className=`tile ${(file+rank)%2?'light':'dark'}${selected===square?' selected':''}`;
    Object.assign(tile.style,{left:x*12.5+'%',top:y*12.5+'%'});tile.dataset.square=square;
    const coord=document.createElement('span');coord.className='coord';coord.textContent=square;tile.append(coord);board.append(tile);
    const p=game.get(square);if(p){const piece=document.createElement('div');piece.className=`piece ${p.color+p.type} square-${file+1}${rank}${p.color==='w'?' white':''}`;piece.textContent=glyph[p.type];piece.dataset.square=square;piece.style.left=x*12.5+'%';piece.style.top=y*12.5+'%';board.append(piece);}
  }
  document.getElementById('demo-status').textContent=game.isCheckmate()?'Checkmate':game.isStalemate()?'Stalemate':`${game.turn()==='w'?'White':'Black'} to move${game.isCheck()?' · Check':''}`;
}
board.addEventListener('click',e=>{const square=e.target.closest('[data-square]')?.dataset.square;if(!square)return;if(selected){try{game.move({from:selected,to:square,promotion:'q'});selected=null;render();return;}catch{}}selected=game.get(square)?.color===game.turn()?square:null;render();});
document.getElementById('flip').onclick=()=>{flipped=!flipped;render();};
document.getElementById('undo').onclick=()=>{game.undo();selected=null;render();};
document.getElementById('reset').onclick=()=>{game=new Chess(presets[document.getElementById('preset').value]);selected=null;render();};
document.getElementById('preset').onchange=()=>document.getElementById('reset').click();
render();
