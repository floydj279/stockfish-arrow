// GPL-3.0-or-later. UCI lifecycle is serialized so stale searches cannot leak into a new position.
// Unmodified worker from npm stockfish@17.1.0, lite single-threaded build 03e3232.
// Keep this filename and its same-name .wasm companion together in vendor/.
export const ENGINE_WORKER_PATH = 'vendor/stockfish-17.1-lite-single-03e3232.js';
export function parseInfo(line) {
  if (!line.startsWith('info ')) return null;
  const depth = line.match(/\bdepth (\d+)/);
  const score = line.match(/\bscore (cp|mate) (-?\d+)/);
  const pv = line.match(/\bpv (.+)$/);
  return {
    depth: depth ? Number(depth[1]) : undefined,
    score: score ? {type: score[1], value: Number(score[2]), pov: 'side-to-move'} : undefined,
    pv: pv ? pv[1].split(' ').filter(move => /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move)).slice(0, 40) : undefined,
  };
}

export class EngineController {
  constructor(workerFactory, options = {}) {
    this.workerFactory = workerFactory;
    this.worker = null;
    this.state = 'idle';
    this.pending = new Map();
    this.active = null;
    this.timer = null;
    this.idleTimer = null;
    this.maxQueue = options.maxQueue || 8;
    this.idleTimeout = options.idleTimeout ?? 60000;
  }

  analyze(request) {
    return new Promise(resolve => {
      this.cancel(request.clientId, undefined, {keepWarm: true});
      if (this.pending.size >= this.maxQueue) {
        resolve(this.result(request, {ok: false, error: 'Several boards are analyzing. Try again shortly.'}));
        return;
      }
      this.pending.set(request.clientId, {...request, resolve, settled: false, info: {score: null, depth: 0, pv: []}});
      this.pump();
    });
  }

  result(job, data) {
    return {requestId: job.requestId, fen: job.fen, ...data};
  }

  settle(job, data) {
    if (!job || job.settled) return;
    job.settled = true;
    job.resolve(this.result(job, data));
  }

  cancel(clientId, requestId, {keepWarm = false} = {}) {
    let cancelled = false;
    const pending = this.pending.get(clientId);
    const matches = job => job && (requestId === undefined || requestId === job.requestId);
    if (matches(pending)) {
      this.pending.delete(clientId);
      this.settle(pending, {ok: false, cancelled: true, error: 'Analysis cancelled.'});
      cancelled = true;
    }
    if (this.active?.clientId === clientId && matches(this.active) && !this.active.cancelled) {
      this.active.cancelled = true;
      this.settle(this.active, {ok: false, cancelled: true, error: 'Analysis cancelled.'});
      if (!keepWarm && !this.pending.size) {
        this.active = null;
        this.destroyWorker();
        return true;
      }
      this.state = 'stopping';
      this.worker.postMessage('stop');
      this.setTimer(() => {
        this.destroyWorker();
        this.active = null;
        this.pump();
      }, 2000);
      cancelled = true;
    }
    // An explicit disable/tab-close should stop compilation too, not only search.
    // Replacements keep the initialized engine warm while a new request is queued.
    if (!keepWarm && !this.active && !this.pending.size) this.destroyWorker();
    return cancelled;
  }

  setTimer(callback, delay) {
    clearTimeout(this.timer);
    this.timer = setTimeout(callback, delay);
  }

  startWorker() {
    try {
      this.worker = this.workerFactory();
      this.state = 'loading';
      const worker = this.worker;
      worker.onmessage = event => {
        if (worker !== this.worker) return;
        String(event.data).split(/\r?\n/).forEach(line => this.onLine(line.trim()));
      };
      worker.onerror = event => {
        event.preventDefault?.();
        if (worker === this.worker) this.fail('Stockfish could not load. Check the bundled engine files and reload the extension.');
      };
      this.setTimer(() => this.fail('Stockfish took too long to initialize.'), 20000);
      worker.postMessage('uci');
    } catch (error) {
      this.fail(`Stockfish could not start: ${error.message}`);
    }
  }

  pump() {
    clearTimeout(this.idleTimer);
    if (!this.pending.size) {
      if (!this.active && this.worker && this.state === 'ready') {
        this.idleTimer = setTimeout(() => this.destroyWorker(), this.idleTimeout);
      }
      return;
    }
    if (!this.worker) { this.startWorker(); return; }
    if (this.state !== 'ready' || this.active) return;
    const [clientId, job] = this.pending.entries().next().value;
    this.pending.delete(clientId);
    this.active = job;
    this.state = 'searching';
    this.worker.postMessage('ucinewgame');
    this.worker.postMessage(`position fen ${job.fen}`);
    this.worker.postMessage(`go depth ${job.depth} movetime ${job.movetime}`);
    this.setTimer(() => this.fail('Stockfish did not finish in time. Try a shorter analysis.'), job.movetime + 10000);
  }

  onLine(line) {
    if (this.state === 'loading' && line === 'uciok') {
      this.worker.postMessage('setoption name Hash value 32');
      this.worker.postMessage('setoption name Threads value 1');
      this.worker.postMessage('isready');
      return;
    }
    if (this.state === 'loading' && line === 'readyok') {
      clearTimeout(this.timer);
      this.state = 'ready';
      this.pump();
      return;
    }
    if (!this.active) return;
    if (line.startsWith('info ') && this.state === 'searching') {
      const info = parseInfo(line);
      for (const [key, value] of Object.entries(info)) if (value !== undefined) this.active.info[key] = value;
    }
    if (!line.startsWith('bestmove ')) return;
    clearTimeout(this.timer);
    const job = this.active;
    const candidate = line.split(/\s+/)[1];
    const move = /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(candidate) ? candidate : null;
    if (!job.cancelled) {
      if (!move && !['(none)', '0000'].includes(candidate)) {
        this.settle(job, {ok: false, error: 'Stockfish returned an invalid move.'});
      } else {
        this.settle(job, {ok: true, bestmove: move, ...job.info});
      }
    }
    this.active = null;
    this.state = 'ready';
    this.pump();
  }

  destroyWorker() {
    clearTimeout(this.timer);
    clearTimeout(this.idleTimer);
    this.worker?.terminate();
    this.worker = null;
    this.state = 'idle';
  }

  fail(error) {
    this.settle(this.active, {ok: false, error});
    this.active = null;
    for (const job of this.pending.values()) this.settle(job, {ok: false, error});
    this.pending.clear();
    this.destroyWorker();
  }

  dispose() { this.fail('Engine closed.'); }
}

if (globalThis.chrome?.runtime?.onMessage && globalThis.Worker) {
  const engine = new EngineController(() => new Worker(chrome.runtime.getURL(ENGINE_WORKER_PATH)));
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.target !== 'stockfish-offscreen' || sender.id !== chrome.runtime.id || sender.tab) return;
    if (message.type === 'ANALYZE') {
      engine.analyze(message).then(sendResponse);
      return true;
    }
    if (message.type === 'CANCEL') {
      sendResponse({ok: true, requestId: message.requestId, cancelled: engine.cancel(message.clientId, message.requestId)});
    }
  });
}
