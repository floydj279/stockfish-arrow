STOCKFISH ARROW — Chrome extension, version 1.0.0

INSTALL (no Node, Python, API key, or subscription needed)
1. Extract this ZIP into a permanent folder. Keep all files together.
2. Open chrome://extensions in Google Chrome.
3. Turn on Developer mode in the upper-right corner.
4. Click Load unpacked and choose THIS folder (the one containing manifest.json).
5. Refresh any Chess.com tab that was already open.
6. Open a board and click Enable arrow in the floating Stockfish Arrow panel.
   You can also pin the extension and click its icon, or press Alt+Shift+S.

USE
- Open before the first move for automatic position tracking. The extension
  reads the rendered board, tracks legal moves, and draws Stockfish's suggestion.
- The arrow supports either board orientation and follows scrolling/resizing.
- Drag the panel by its header; use the minus button to collapse it.
- Think time ranges from 0.5 to 10 seconds. More time can improve the result.
  The displayed move is the engine's best result for that search, not a proof
  of a mathematically perfect move. The engine is Stockfish 17.1 Lite, single
  threaded, with its smaller bundled neural network.
- The score uses White's perspective; +1.00 favors White by about one pawn.
- Nothing moves automatically. Click your own moves.
- Pause arrow stops analysis and removes the arrow.

IF YOU OPEN AN EXISTING POSITION
Piece locations alone do not reveal side to move, castling rights, en passant,
or move counters. Open Position setup and paste the current full FEN. The FEN
must match the board on screen. Alternatively, choose White/Black to move,
check the castling rights still available, and specify an en passant target
square if one exists, then click Use board + these settings. Unchecked rights
mean no castling; '-' means no en passant. That alternative starts counters
at 0 and 1, so use a full FEN when move counters matter.

The extension tracks subsequent single legal moves. If it misses multiple
moves, you switch variations, or return after the tab was hidden, resynchronize
using FEN if requested. Multiple visible boards: the largest visible supported
board is used. Standard chess only; Chess960 and other variants are unsupported.

PRACTICE / QUICK CHECK
Click the extension icon on a non-Chess.com tab to open the bundled practice
board. Select Mate in one, then Enable arrow: the expected move is Rd8#.
Flip the board and the arrow should remain on d1–d8.

FAIR PLAY
Use for analysis, finished games, and bot practice. Chess.com prohibits engine
help in games against other users, including Daily games, and may close an
account for violations. Bot games are exempt under its published policy:
https://www.chess.com/legal/fair-play
The extension does not determine whether a board belongs to a permitted game.
You are responsible for choosing where to enable it.

PRIVACY / PERMISSIONS
All analysis runs locally in the bundled engine. No API keys, account access,
screen capture, analytics, or remote engine service. Only think-time preference
is stored locally. It reads board elements on chess.com and www.chess.com.
The offscreen permission runs Stockfish in a worker; storage saves think time.
No cookies, passwords, browsing history, or chess positions are uploaded.

TROUBLESHOOTING
- No panel: confirm the extension is enabled, allow it on Chess.com, and refresh.
- Position setup needed: follow the FEN/setup instructions above.
- Analysis unavailable: pause/enable again; if extension was reloaded, refresh
  Chess.com. Check chrome://extensions > Stockfish Arrow > Errors.
- Engine startup can take a moment on slower machines.
- Only the largest DOM-based Chess.com board is supported; site updates may
  require a board-reader update. It cannot read screenshots or canvas boards.
- Keep the extracted folder: Chrome loads files from that exact location.

SOURCE AND DEVELOPMENT
Source is included under src/. content.bundle.js is the generated content script.
Rebuild using Node 20+: node build.mjs
Run unit tests: node --test tests/*.test.mjs
Read licenses/SOURCES.txt for upstream dependency provenance and source code.
The extension's original code is licensed GPL-3.0-or-later; the bundled Stockfish
and chess.js retain their respective notices. Not affiliated with Chess.com.
