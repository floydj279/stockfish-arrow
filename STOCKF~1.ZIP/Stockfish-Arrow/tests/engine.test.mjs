import test from 'node:test';
import assert from 'node:assert/strict';
import {EngineController, parseInfo} from '../src/offscreen.js';
import {validFen, allowedSender} from '../src/background.js';

const FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
function harness() {
  const commands = [];
  const worker = {postMessage: command => commands.push(command), terminate() {this.terminated = true;}};
  const engine = new EngineController(() => worker);
  return {engine, worker, commands, ready() {worker.onmessage({data: 'uciok'}); worker.onmessage({data: 'readyok'});}, emit(line) {worker.onmessage({data: line});}};
}
function request(requestId, clientId = 'tab:1') {return {requestId, clientId, fen: FEN, movetime: 100, depth: 12};}

test('FEN validation rejects missing kings, malformed ranks and UCI injection', () => {
  assert.equal(validFen(FEN), true);
  assert.equal(validFen(FEN + '\ngo infinite'), false);
  assert.equal(validFen(FEN.replace('RNBQKBNR', 'RNBQ1BNR')), false);
  assert.equal(validFen(FEN.replace('/8/', '/9/')), false);
});

test('only owned extension or Chess.com top-level contexts may request analysis', () => {
  const base = {id: 'test', frameId: 0};
  assert.equal(allowedSender({...base, url: 'https://www.chess.com/analysis'}, 'test'), true);
  assert.equal(allowedSender({...base, url: 'https://chess.com.evil.test/'}, 'test'), false);
  assert.equal(allowedSender({...base, url: 'chrome-extension://test/demo.html'}, 'test'), true);
  assert.equal(allowedSender({...base, frameId: 1, url: 'https://www.chess.com/'}, 'test'), false);
});

test('UCI handshake precedes search and returns parsed score/PV', async () => {
  const h = harness();
  const result = h.engine.analyze(request(1));
  assert.deepEqual(h.commands, ['uci']);
  h.ready();
  assert.ok(h.commands.includes(`position fen ${FEN}`));
  h.emit('info depth 12 score cp 31 nodes 123 pv e2e4 e7e5 g1f3');
  h.emit('bestmove e2e4 ponder e7e5');
  assert.deepEqual(await result, {ok: true, requestId: 1, fen: FEN, bestmove: 'e2e4', depth: 12, score: {type: 'cp', value: 31, pov: 'side-to-move'}, pv: ['e2e4', 'e7e5', 'g1f3']});
  h.engine.dispose();
});

test('replacement drains cancelled bestmove before beginning fresh position', async () => {
  const h = harness();
  const old = h.engine.analyze(request(1));
  h.ready();
  const fresh = h.engine.analyze(request(2));
  assert.equal((await old).cancelled, true);
  assert.equal(h.commands.at(-1), 'stop');
  assert.equal(h.commands.filter(command => command.startsWith('go ')).length, 1);
  h.emit('info depth 10 score mate 1 pv a2a4');
  h.emit('bestmove a2a4');
  assert.equal(h.commands.filter(command => command.startsWith('go ')).length, 2);
  h.emit('info depth 9 score cp 20 pv d2d4');
  h.emit('bestmove d2d4');
  assert.equal((await fresh).bestmove, 'd2d4');
  h.engine.dispose();
});

test('cancelling one tab leaves another queued tab intact', async () => {
  const h = harness();
  const one = h.engine.analyze(request(1));
  h.ready();
  const two = h.engine.analyze(request(2, 'tab:2'));
  assert.equal(h.engine.cancel('tab:1', 999), false);
  assert.equal(h.engine.cancel('tab:1', 1), true);
  h.emit('bestmove e2e4');
  h.emit('bestmove d2d4');
  assert.equal((await one).cancelled, true);
  assert.equal((await two).bestmove, 'd2d4');
  h.engine.dispose();
});

test('checkmate/stalemate returns no move and worker failure settles requests', async () => {
  const h = harness();
  const one = h.engine.analyze(request(1));
  h.ready();
  h.emit('info depth 0 score mate 0');
  h.emit('bestmove (none)');
  assert.equal((await one).bestmove, null);
  const two = h.engine.analyze(request(2));
  h.worker.onerror({preventDefault() {}});
  assert.equal((await two).ok, false);
  assert.equal(h.worker.terminated, true);
  h.engine.dispose();
});

test('parser understands negative mate and ignores invalid PV tokens', () => {
  assert.deepEqual(parseInfo('info depth 7 score mate -3 pv a7a8q garbage h8g7'), {depth: 7, score: {type: 'mate', value: -3, pov: 'side-to-move'}, pv: ['a7a8q', 'h8g7']});
});

test('explicit cancellation terminates initializing and active workers when no other tab waits', async () => {
  const loading = harness();
  const pending = loading.engine.analyze(request(1));
  assert.equal(loading.engine.cancel('tab:1'), true);
  assert.equal((await pending).cancelled, true);
  assert.equal(loading.worker.terminated, true);
  assert.equal(loading.engine.active, null);
  assert.equal(loading.engine.pending.size, 0);
  const running = harness();
  const active = running.engine.analyze(request(2));
  running.ready();
  running.engine.cancel('tab:1');
  assert.equal((await active).cancelled, true);
  assert.equal(running.worker.terminated, true);
  assert.equal(running.engine.state, 'idle');
});

test('a delayed cancellation cannot stop the next analysis request', async () => {
  const originalChrome = globalThis.chrome;
  let listener;
  let finishCancelLookup;
  let delayNextLookup = false;
  const forwarded = [];
  const sender = {id: 'test', frameId: 0, url: 'https://www.chess.com/analysis', tab: {id: 1}};
  globalThis.chrome = {
    runtime: {
      id: 'test',
      getURL: path => `chrome-extension://test/${path}`,
      onMessage: {addListener(fn) {listener = fn;}},
      getContexts() {
        if (delayNextLookup) {
          delayNextLookup = false;
          return new Promise(resolve => {finishCancelLookup = resolve;});
        }
        return Promise.resolve([{}]);
      },
      sendMessage: async message => {forwarded.push(message); return {ok: true, requestId: message.requestId};},
    },
    offscreen: {createDocument: async () => {}},
    tabs: {onRemoved: {addListener() {}}, query: async () => [], sendMessage: async () => {}, create() {}},
    action: {onClicked: {addListener() {}}},
    commands: {onCommand: {addListener() {}}},
  };
  try {
    await import('../src/background.js?cancellation-regression');
    const send = message => new Promise(resolve => listener(message, sender, resolve));
    await send({type: 'ANALYZE', fen: FEN, requestId: 1});
    delayNextLookup = true;
    const staleCancel = send({type: 'CANCEL'});
    assert.equal(typeof finishCancelLookup, 'function');
    await send({type: 'ANALYZE', fen: FEN, requestId: 2});
    finishCancelLookup([{}]);
    assert.equal((await staleCancel).cancelled, false);
    assert.deepEqual(forwarded.map(message => [message.type, message.requestId]), [['ANALYZE', 1], ['ANALYZE', 2]]);

    await send({type: 'CANCEL'});
    assert.deepEqual([forwarded.at(-1).type, forwarded.at(-1).requestId], ['CANCEL', 2]);
  } finally {
    if (originalChrome === undefined) delete globalThis.chrome;
    else globalThis.chrome = originalChrome;
  }
});
