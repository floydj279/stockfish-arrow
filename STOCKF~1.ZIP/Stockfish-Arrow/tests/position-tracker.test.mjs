import test from 'node:test';
import assert from 'node:assert/strict';
import {Chess} from '../vendor/chess.mjs';
import {PositionTracker} from '../src/position-tracker.js';

const snapshot = (game, extras = {}) => ({placement: game.fen().split(' ')[0], ...extras});
function advance(game, tracker, san) {
  game.move(san);
  const result = tracker.update(snapshot(game));
  assert.equal(result.fen, game.fen(), `Tracking ${san}`);
  return result;
}

test('recognizes starting board and tracks a legal opening automatically', () => {
  const game = new Chess(), tracker = new PositionTracker();
  assert.equal(tracker.update(snapshot(game)).source, 'start-position');
  for (const san of ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6', 'O-O']) advance(game, tracker, san);
  assert.equal(tracker.currentFen.split(' ')[2], 'kq');
});

test('tracks en passant and retains the disappearing pawn correctly', () => {
  const game = new Chess(), tracker = new PositionTracker();
  tracker.update(snapshot(game));
  for (const san of ['e4', 'a6', 'e5', 'd5', 'exd6']) advance(game, tracker, san);
  assert.equal(game.get('d5'), undefined);
  assert.equal(game.get('d6').type, 'p');
});

test('tracks underpromotion from a full FEN seed', () => {
  const game = new Chess('7k/P7/8/8/8/8/8/7K w - - 0 1');
  const tracker = new PositionTracker();
  assert.equal(tracker.seed(game.fen()).source, 'manual');
  advance(game, tracker, 'a8=N');
  assert.equal(game.get('a8').type, 'n');
});

test('stepping backwards and forwards restores exact FEN metadata', () => {
  const game = new Chess(), tracker = new PositionTracker();
  const states = [game.fen()];
  tracker.update(snapshot(game));
  for (const san of ['e4', 'e5', 'Nf3', 'Nc6']) {
    advance(game, tracker, san);
    states.push(game.fen());
  }
  for (const index of [3, 2, 3, 4, 0]) {
    const saved = new Chess(states[index]);
    assert.equal(tracker.update(snapshot(saved)).fen, states[index]);
  }
});

test('does not invent metadata when attached to an unknown midgame', () => {
  const game = new Chess();
  game.move('e4'); game.move('e5');
  const result = new PositionTracker().update(snapshot(game));
  assert.equal(result.fen, null);
  assert.match(result.warning, /full FEN/);
});

test('matching explicit FEN overrides inference, mismatch fails visibly', () => {
  const tracker = new PositionTracker(), game = new Chess();
  tracker.update(snapshot(game));
  game.move('e4'); game.move('e5');
  assert.equal(tracker.update(snapshot(game, {fen:game.fen(),source:'visible-fen'})).source, 'visible-fen');
  assert.equal(tracker.update(snapshot(game, {fen:new Chess().fen()})).fen, null);
  assert.match(tracker.update(snapshot(game, {fen:'invalid'})).error, /Invalid/);
});

test('explicit turn conflicts do not silently reuse current state', () => {
  const tracker = new PositionTracker(), game = new Chess();
  tracker.update(snapshot(game));
  const result = tracker.update(snapshot(game, {turn:'b'}));
  assert.equal(result.fen, null);
});

test('unknown transient board does not destroy a known legal position', () => {
  const tracker = new PositionTracker(), game = new Chess();
  tracker.update(snapshot(game));
  assert.equal(tracker.update({placement:null,error:'animation'}).error, 'animation');
  advance(game, tracker, 'e4');
});

test('unobserved skipped positions require FEN instead of guessed rights', () => {
  const tracker = new PositionTracker(), game = new Chess();
  tracker.update(snapshot(game));
  game.move('e4'); game.move('e5');
  assert.equal(tracker.update(snapshot(game)).fen, null);
  assert.equal(tracker.seed(game.fen()).fen, game.fen());
  advance(game, tracker, 'Nf3');
});

test('reset and invalid seeds do not retain or invent state', () => {
  const tracker = new PositionTracker(), game = new Chess();
  tracker.update(snapshot(game));
  assert.equal(tracker.seed('broken').fen, null);
  assert.equal(tracker.currentFen, game.fen());
  tracker.reset();
  assert.equal(tracker.currentFen, null);
  assert.equal(tracker.history.length, 0);
});

test('repeated positions prefer legal current transitions over older snapshots', () => {
  const tracker = new PositionTracker(), game = new Chess();
  tracker.update(snapshot(game));
  for (const san of ['Nf3', 'Nf6', 'Ng1', 'Ng8', 'Nf3', 'Nf6', 'Ng1', 'Ng8']) advance(game, tracker, san);
  assert.equal(tracker.currentFen.split(' ')[4], '8');
});

test('ambiguous nonadjacent history is not assigned an arbitrary move counter', () => {
  const tracker = new PositionTracker(), game = new Chess();
  tracker.update(snapshot(game));
  for (const san of ['Nf3', 'Nf6', 'Ng1', 'Ng8', 'Nf3', 'Nf6', 'Ng1', 'Ng8', 'e4', 'e5']) advance(game, tracker, san);
  const result = tracker.update(snapshot(new Chess()));
  assert.equal(result.fen, null);
  assert.match(result.warning, /more than once/);
});
