import test from 'node:test';
import assert from 'node:assert/strict';
// Data URL keeps this test independent of the root project's package type.
import {readFile} from 'node:fs/promises';
const source = await readFile(new URL('../src/board-reader.js', import.meta.url), 'utf8');
const {parseSquareClass, piecesToPlacement, parseFen, squareCenter, readBoard} = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));

const start = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR';
const startFen = start + ' w KQkq - 0 1';

function element(attrs = {}, children = [], size = 400) {
  return {
    getAttribute: name => attrs[name] ?? null,
    getBoundingClientRect: () => ({width: size, height: size}),
    querySelectorAll: selector => selector === '.piece' ? children : [],
    value: attrs.value || '',
    hidden: attrs.hidden || false,
  };
}
function pieces(placement) {
  const output = [];
  placement.split('/').forEach((rank, y) => {
    let x = 1;
    for (const char of rank) {
      if (/\d/.test(char)) { x += Number(char); continue; }
      output.push(element({class: `piece ${char === char.toUpperCase() ? 'w' : 'b'}${char.toLowerCase()} square-${x}${8 - y}`}));
      x++;
    }
  });
  return output;
}
function documentWith(boards, fields = []) {
  return {
    querySelectorAll: selector => selector === 'wc-chess-board, chess-board' ? boards : fields,
    defaultView: {getComputedStyle: () => ({display: 'block', visibility: 'visible', opacity: '1'})},
  };
}

test('piece classes map file then rank and reject malformed squares', () => {
  assert.equal(parseSquareClass('piece wp square-52'), 'e2');
  assert.equal(parseSquareClass('square-18 piece br'), 'a8');
  assert.equal(parseSquareClass('square-99'), null);
  assert.equal(parseSquareClass('not-square-52'), null);
});

test('placement runs contain proper empty-square counts and colors', () => {
  assert.equal(piecesToPlacement([{piece:'bk',square:'e8'}, {piece:'wk',square:'e1'}, {piece:'wp',square:'e2'}]), '4k3/8/8/8/8/8/4P3/4K3');
  assert.throws(() => piecesToPlacement([{piece:'wk',square:'e1'}, {piece:'wk',square:'e1'}]), /overlap/);
  assert.throws(() => piecesToPlacement([{piece:'wx',square:'e1'}]), /unrecognized/);
});

test('FEN validation rejects incomplete and inconsistent metadata', () => {
  assert.equal(parseFen(startFen).fen, startFen);
  assert.equal(parseFen(start), null);
  assert.equal(parseFen(start + ' w KQkq e3 0 1'), null);
  assert.equal(parseFen(start + ' w KK - 0 1'), null);
  assert.equal(parseFen(start + ' x - - 0 1'), null);
  assert.equal(parseFen('44/8/8/8/8/8/8/8 w - - 0 1'), null);
});

test('arrows remain centered when the board flips', () => {
  assert.deepEqual(squareCenter('a8'), {x: 0.0625, y: 0.0625});
  assert.deepEqual(squareCenter('a8', true), {x: 0.9375, y: 0.9375});
  assert.deepEqual(squareCenter('e2'), {x: 0.5625, y: 0.8125});
  assert.throws(() => squareCenter('i9'), /Invalid/);
});

test('reads the largest visible board and preserves exact matching FEN', () => {
  const board = element({fen: startFen, class: 'board flipped'}, pieces(start), 600);
  const result = readBoard(documentWith([element({}, pieces(start), 100), board]));
  assert.equal(result.boardElement, board);
  assert.equal(result.fen, startFen);
  assert.equal(result.turn, 'w');
  assert.equal(result.flipped, true);
  assert.equal(result.source, 'board-fen');
});

test('never invents side to move or history from pieces', () => {
  const result = readBoard(documentWith([element({}, pieces(start))]));
  assert.equal(result.placement, start);
  assert.equal(result.fen, null);
  assert.equal(result.turn, null);
  assert.match(result.warning, /castling/);
});

test('ignores mismatched or hidden FEN and respects explicit turn attributes', () => {
  const otherFen = '4k3/8/8/8/8/8/8/4K3 b - - 0 1';
  const board = element({'data-fen': otherFen, 'data-turn':'black'}, pieces(start));
  const result = readBoard(documentWith([board], [element({value: startFen, hidden:true})]));
  assert.equal(result.fen, null);
  assert.equal(result.turn, 'b');
});

test('uses a visible FEN field only if its position matches this board', () => {
  const result = readBoard(documentWith([element({}, pieces(start))], [element({value: startFen})]));
  assert.equal(result.fen, startFen);
  assert.equal(result.source, 'visible-fen');
});

test('rejects animation overlap and has no-board state', () => {
  assert.equal(readBoard(documentWith([])), null);
  const overlapping = pieces(start);
  overlapping.push(overlapping[0]);
  const result = readBoard(documentWith([element({}, overlapping)]));
  assert.equal(result.placement, null);
  assert.match(result.error, /overlap/);
});
